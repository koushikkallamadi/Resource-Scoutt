﻿chrome.runtime.onInstalled.addListener(() => {
  console.log('Resource‑Scout background service worker installed');
});
