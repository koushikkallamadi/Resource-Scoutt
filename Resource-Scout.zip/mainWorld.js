﻿console.log('mainWorld script loaded');
